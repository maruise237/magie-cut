This a remix.js app with zustand and axios.
