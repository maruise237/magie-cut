// This file is the entry point for the Vercel serverless function
// It re-exports the handler from the built server file

export * from "../build/server/index.js";
